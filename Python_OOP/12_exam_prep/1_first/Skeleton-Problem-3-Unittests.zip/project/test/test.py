from project.soccer_player import SoccerPlayer

